SWIFT AUDIO — MISSING PLUG-INS DIAGNOSTICS

Use this on the Mac where other plug-ins appeared to disappear.
It does not install Swift Audio or alter any other plug-in.

1. Before moving plug-ins, reinstalling, changing Logic launch mode, or resetting
   caches, unzip this package and open Collect-Diagnostics.command.
2. A new Swift-Audio-diagnostics folder appears on your Desktop. The script only
   lists registrations, installed component names, version/hash information and
   relevant crash-report paths. No plug-in is removed, disabled or rescanned.
3. Review the files (they contain local paths and plug-in names), then send that
   folder to Oliver along with:
   - at least one missing plug-in's name;
   - whether it is missing from a track slot, the Audio FX menu, or Plug-in Manager;
   - Mac type, macOS and Logic versions;
   - whether Logic's Open using Rosetta setting changed;
   - any error message and a screenshot of the missing plug-in's Plug-in Manager
     row with search cleared and Show All selected, where available.

If macOS blocks the script, send the information in step 3 instead. No security
settings need to be disabled. Do not reinstall the affected plug-ins or reset
all Audio Units before preserving the evidence.
